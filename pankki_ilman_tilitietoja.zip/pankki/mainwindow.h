#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDebug>
#include <QString>
#include "dialog.h"
#include "rfiddll.h"
#include "rfiddll_global.h"
#include "tietokantadll.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:

    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    RfidDll *objectRfidDll;
    returnCardSerialNumber();
    void checkCard();
    void checkPin();
    void mainView();
    Dialog *objectDialog;
    QString palautettuPin;
    QString kortti;
    QString vertaa;
    bool oikein = false;
    bool vertaaPin();
    int x,y =0;
    TietokantaDLL *objectTietokantaDLL;
    void loginCheck();
    void Login();
    float nostettavaSumma;
    QString nostoOnnistui = "Nosto onnistui, tilin saldo on: ";
    float naytaSaldo;

public slots:

    void receiveSerialData();
    void pinNumber();

private slots:

    void successslot();
    void failedSlot();
    void on_pushButtonNosto_clicked();
    void on_pushButtonSaldo_clicked();
    void on_pushButtonTilitiedot_clicked();
    void on_pushButtonPalaa_clicked();
    void on_pushButtonLogout_clicked();
    void on_pushButtonNosta20_clicked();
    void on_pushButtonNosta50_clicked();
    void on_pushButtonNosta100_clicked();
    void on_pushButtonNosta500_clicked();
    void on_pushButtonRelog_clicked();

private:

    Ui::MainWindow *ui;

};

#endif // MAINWINDOW_H
