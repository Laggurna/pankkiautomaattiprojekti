#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QThread>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    objectRfidDll = new RfidDll;
    objectTietokantaDLL = new TietokantaDLL;

    connect(objectRfidDll,SIGNAL(dataReadDone()),this, SLOT(receiveSerialData()));
    objectTietokantaDLL->connectToDatabase();
    connect(objectTietokantaDLL,SIGNAL(failedsignal()),this,SLOT(failedSlot()));
    connect(objectTietokantaDLL,SIGNAL(successsignal()),this,SLOT(successslot()));
    y = 0;
    x = 0;

    this->Login();
}

void MainWindow::Login()
{


    ui->labelTervetuloa->setHidden(false);
    ui->labelKortti->setHidden(false);

    ui->labelNaytto->setHidden(true);
    ui->labelChecked1->setHidden(true);
    ui->labelChecked2->setHidden(true);
    ui->labelTunnus->setHidden(true);
    ui->pushButtonNosto->setHidden(true);
    ui->pushButtonSaldo->setHidden(true);
    ui->pushButtonTilitiedot->setHidden(true);
    ui->pushButtonNosta20->setHidden(true);
    ui->pushButtonNosta50->setHidden(true);
    ui->pushButtonNosta100->setHidden(true);
    ui->pushButtonNosta500->setHidden(true);
    ui->pushButtonPalaa->setHidden(true);
    ui->pushButtonLogout->setHidden(true);
    ui->pushButtonRelog->setHidden(true);

}

MainWindow::~MainWindow()
{
    delete ui;
    delete objectRfidDll;
}

void MainWindow::receiveSerialData()
{
    this->checkCard();
}

void MainWindow::checkCard()
{
    y++;
    if (y==1)
    {
        QString kortti = objectRfidDll->returnCardSerialNumber();
        if (kortti.size() == 10)
        {
            ui->labelChecked1->setHidden(false);
            ui->labelTunnus->setHidden(false);
            this->checkPin();
        }

    }

}

void MainWindow::checkPin()
{
    x++;
    if (x==1)
    {
        objectDialog = new Dialog;
        objectDialog->show();
        connect(objectDialog,SIGNAL(pinSignaali()),this, SLOT(pinNumber()));
    }
}

void MainWindow::pinNumber()
{
    kortti = objectRfidDll->returnCardSerialNumber();
    palautettuPin = objectDialog->returnPin();
    objectTietokantaDLL->tietokantaLogin(kortti,palautettuPin);
    this->loginCheck();
}

void MainWindow::loginCheck()
{
    if (objectTietokantaDLL->vertaaNumeroita() == true)
    {
        objectDialog->setVisible(false);
        this->mainView();
    }
}

void MainWindow::mainView()
{
    ui->labelNaytto->setText("Valitse tapahtuma vasemmalla olevista painikkeista");
    ui->labelTervetuloa->setHidden(true);
    ui->labelKortti->setHidden(true);
    ui->labelTunnus->setHidden(true);
    ui->labelChecked1->setHidden(true);
    ui->labelChecked2->setHidden(true);
    ui->labelNaytto->setHidden(false);
    ui->pushButtonNosto->setHidden(false);
    ui->pushButtonSaldo->setHidden(false);
    ui->pushButtonTilitiedot->setHidden(false);
    ui->pushButtonLogout->setHidden(false);
}

void MainWindow::on_pushButtonNosto_clicked()
{
    ui->labelNaytto->clear();
    ui->pushButtonNosta20->setHidden(false);
    ui->pushButtonNosta50->setHidden(false);
    ui->pushButtonNosta100->setHidden(false);
    ui->pushButtonNosta500->setHidden(false);
    ui->pushButtonPalaa->setHidden(true);
}

void MainWindow::on_pushButtonSaldo_clicked()
{
    ui->labelNaytto->clear();
    ui->labelTervetuloa->setHidden(true);
    ui->labelKortti->setHidden(true);
    ui->labelTunnus->setHidden(true);
    ui->labelChecked1->setHidden(true);
    ui->labelChecked2->setHidden(true);
    ui->labelNaytto->setHidden(false);
    ui->pushButtonNosto->setHidden(false);
    ui->pushButtonSaldo->setHidden(false);
    ui->pushButtonTilitiedot->setHidden(false);
    ui->pushButtonLogout->setHidden(false);
    ui->pushButtonNosta20->setHidden(true);
    ui->pushButtonNosta50->setHidden(true);
    ui->pushButtonNosta100->setHidden(true);
    ui->pushButtonNosta500->setHidden(true);

    objectTietokantaDLL->naytaSaldo();
    float naytaSaldo = objectTietokantaDLL->returnSaldo();
    QString saldonNaytto = QString::number(naytaSaldo);
    ui->labelNaytto->setText("Tilin saldo on " + saldonNaytto + " €");
}

void MainWindow::on_pushButtonTilitiedot_clicked()
{
    ui->labelNaytto->clear();
    ui->pushButtonNosta20->setHidden(true);
    ui->pushButtonNosta50->setHidden(true);
    ui->pushButtonNosta100->setHidden(true);
    ui->pushButtonNosta500->setHidden(true);
    ui->pushButtonPalaa->setHidden(true);



    // logi tähän


}

void MainWindow::on_pushButtonPalaa_clicked()
{
    ui->labelNaytto->clear();
    ui->pushButtonNosta20->setHidden(true);
    ui->pushButtonNosta50->setHidden(true);
    ui->pushButtonNosta100->setHidden(true);
    ui->pushButtonNosta500->setHidden(true);
    ui->pushButtonPalaa->setHidden(true);
}

void MainWindow::on_pushButtonLogout_clicked()
{
    x=0;
    y=0;
    this->Login();
}

void MainWindow::failedSlot()
{
    ui->labelNaytto->setText("Nosto epäonnistui, tilillä ei tarpeeksi katetta.");
    ui->labelTervetuloa->setHidden(true);
    ui->labelKortti->setHidden(true);
    ui->labelChecked1->setHidden(true);
    ui->labelChecked2->setHidden(true);
    ui->labelTunnus->setHidden(true);
    ui->pushButtonNosto->setHidden(true);
    ui->pushButtonSaldo->setHidden(true);
    ui->pushButtonTilitiedot->setHidden(true);
    ui->pushButtonNosta20->setHidden(true);
    ui->pushButtonNosta50->setHidden(true);
    ui->pushButtonNosta100->setHidden(true);
    ui->pushButtonNosta500->setHidden(true);
    ui->pushButtonPalaa->setHidden(true);
    ui->pushButtonLogout->setHidden(true);
    ui->pushButtonRelog->setHidden(false);
}

void MainWindow::on_pushButtonNosta20_clicked()
{
    ui->pushButtonNosta20->setHidden(true);
    ui->pushButtonNosta50->setHidden(true);
    ui->pushButtonNosta100->setHidden(true);
    ui->pushButtonNosta500->setHidden(true);
    ui->pushButtonPalaa->setHidden(true);
    nostettavaSumma=20;
    objectTietokantaDLL->nosto(nostettavaSumma);
}

void MainWindow::on_pushButtonNosta50_clicked()
{
    ui->pushButtonNosta20->setHidden(true);
    ui->pushButtonNosta50->setHidden(true);
    ui->pushButtonNosta100->setHidden(true);
    ui->pushButtonNosta500->setHidden(true);
    ui->pushButtonPalaa->setHidden(true);
    nostettavaSumma=50;
    objectTietokantaDLL->nosto(nostettavaSumma);
}

void MainWindow::on_pushButtonNosta100_clicked()
{
    ui->pushButtonNosta20->setHidden(true);
    ui->pushButtonNosta50->setHidden(true);
    ui->pushButtonNosta100->setHidden(true);
    ui->pushButtonNosta500->setHidden(true);
    ui->pushButtonPalaa->setHidden(true);
    nostettavaSumma=100;
    objectTietokantaDLL->nosto(nostettavaSumma);
}

void MainWindow::on_pushButtonNosta500_clicked()
{
    ui->pushButtonNosta20->setHidden(true);
    ui->pushButtonNosta50->setHidden(true);
    ui->pushButtonNosta100->setHidden(true);
    ui->pushButtonNosta500->setHidden(true);
    ui->pushButtonPalaa->setHidden(true);
    nostettavaSumma=500;
    objectTietokantaDLL->nosto(nostettavaSumma);

}

void MainWindow::successslot()
{
    ui->labelTervetuloa->setHidden(true);
    ui->labelKortti->setHidden(true);
    ui->labelChecked1->setHidden(true);
    ui->labelChecked2->setHidden(true);
    ui->labelTunnus->setHidden(true);
    ui->pushButtonNosto->setHidden(true);
    ui->pushButtonSaldo->setHidden(true);
    ui->pushButtonTilitiedot->setHidden(true);
    ui->pushButtonNosta20->setHidden(true);
    ui->pushButtonNosta50->setHidden(true);
    ui->pushButtonNosta100->setHidden(true);
    ui->pushButtonNosta500->setHidden(true);
    ui->pushButtonPalaa->setHidden(true);
    ui->pushButtonLogout->setHidden(false);
    ui->pushButtonRelog->setHidden(true);

    float tilinsaldo = objectTietokantaDLL->returnRemainingSaldo();
    qDebug() << tilinsaldo;
    QString saldo = QString::number(tilinsaldo);
    ui->labelNaytto->setText(nostoOnnistui + " " + saldo + " €");
}

void MainWindow::on_pushButtonRelog_clicked()
{
    this->on_pushButtonLogout_clicked();
    ui->labelNaytto->clear();
}
