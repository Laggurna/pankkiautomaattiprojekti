#include "tietokantadll.h"




TietokantaDLL::TietokantaDLL()
{
    //kortinnumero = new QString;




tietokanta = new QSqlTableModel;
}


void TietokantaDLL::connectToDatabase()
{
    QStringList list;



    QString name;
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("mysli.oamk.fi");
    db.setDatabaseName("opisk_t6kuve00");

    db.setUserName("t6kuve00");

    db.setPassword("gbakk6UmbWBaBKZf");

    if (!db.open()) {
        qDebug() << "Database error occurred";

    }
    else
    {
        qDebug() << "Database OK";

    }

}

void TietokantaDLL::tietokantaLogin(QString parametriKortti,QString parametriTunnusluku)
{
    kortinnumero = parametriKortti;
    kayttajanSalasana = parametriTunnusluku;
    qDebug()<<kortinnumero;
    qDebug()<<kayttajanSalasana;

    tietokanta = new QSqlTableModel;
    tietokanta->setTable("kortti");
    tietokanta->setFilter(QString("kortti_id = '%1'").arg(kortinnumero));

    //tietokanta->setFilter("kortti_id = '0B0032AD79'");
    //tietokanta->setFilter("tunnusluku = '9876'");

    tietokanta->select();

       kortti_id = tietokanta->data(tietokanta->index(0,0)).toString();
       tunnusluku = tietokanta->data(tietokanta->index(0,1)).toString();

      qDebug() <<kortti_id;
      qDebug() <<tunnusluku;

    this->vertaaNumeroita();

}

bool TietokantaDLL::vertaaNumeroita()
{
    if (kortinnumero == kortti_id && kayttajanSalasana == tunnusluku)
    {
        qDebug()<<"totta";
        return true;

    }

    else
    {
       qDebug()<<"ei";
       return false;
    }

}


void TietokantaDLL::nosto(float parametriNostettavaSumma)
{
    qDebug()<<kortinnumero;
    QSqlQuery tietokanta_nosto;

    tietokanta_nosto.prepare("SELECT saldo FROM tili WHERE kortti_id = :kortinnumero");
    tietokanta_nosto.bindValue(":kortinnumero", kortinnumero);
    tietokanta_nosto.exec();

    while (tietokanta_nosto.next()) {
            saldo = tietokanta_nosto.value(0).toFloat();
            qDebug() << saldo;
       }

    nostettavaSumma = parametriNostettavaSumma;
    qDebug()<<nostettavaSumma;
    this->nostoSuoritus();


}

void TietokantaDLL::nostoSuoritus()
{
    qDebug()<<"täällä";
    QSqlQuery tietokanta_nosto;

    if (nostonTarkistus() == true)
    {
        muutettavaSumma = saldo - nostettavaSumma;
        qDebug()<<muutettavaSumma;
        tietokanta_nosto.prepare("UPDATE tili SET saldo = :muutettavaSumma WHERE kortti_id = :kortinnumero");
        tietokanta_nosto.bindValue(":muutettavaSumma",muutettavaSumma);
        tietokanta_nosto.bindValue(":kortinnumero",kortinnumero);
        tietokanta_nosto.exec();
        emit successsignal();

    }
    else emit failedsignal();
    }

float TietokantaDLL::returnRemainingSaldo()
{
    return muutettavaSumma;
}

void TietokantaDLL::naytaSaldo()
{
    QSqlQuery tietokanta_nosto;


    tietokanta_nosto.prepare("SELECT saldo FROM tili WHERE kortti_id = :kortinnumero");
    tietokanta_nosto.bindValue(":kortinnumero", kortinnumero);
    tietokanta_nosto.exec();

    while (tietokanta_nosto.next()) {
            saldo = tietokanta_nosto.value(0).toFloat();
            qDebug() << saldo;
        }

}

float TietokantaDLL::returnSaldo()
{
    return saldo;
}




bool TietokantaDLL::nostonTarkistus()
{

    if (nostettavaSumma>saldo)
    {
        qDebug()<<"ei toimi";
        return false;

    }
    else
    {
        qDebug()<<"toimii";

        return true;

    }


}

QString TietokantaDLL::nostoEpaonnistui()
{
    QString failed = "Nosto epäonnistui";
    return failed;
}


