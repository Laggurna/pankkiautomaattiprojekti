#ifndef TIETOKANTADLL_H
#define TIETOKANTADLL_H

#include "tietokantadll_global.h"
#include <QtSql>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlDriver>
#include <QtSql/QSqlQuery>
#include <QStringList>
#include <QDebug>
#include <QObject>

class TIETOKANTADLLSHARED_EXPORT TietokantaDLL:public QObject
{
   Q_OBJECT

public:

    TietokantaDLL();
    static bool createConnection();
    void connectToDatabase();
    QSqlTableModel *tietokanta;
    void tietokantaLogin(QString parametriKortti,QString parametriTunnusluku);
    void nosto(float parametriNostettavaSumma);
    bool vertaaNumeroita();
    QString kortinnumero;
    bool nostonTarkistus();
    void nostoSuoritus();
    QString nostoEpaonnistui();
    float returnRemainingSaldo();
    void naytaSaldo();
    float returnSaldo();

private:

    QSqlQuery tietokanta_nosto;
    QString kayttajanSalasana;
    QString kortti_id;
    QString tunnusluku;
    float saldo;
    float nostettavaSumma;
    float muutettavaSumma;

public slots:

signals:

    void failedsignal();
    void successsignal();

};

#endif // TIETOKANTADLL_H
