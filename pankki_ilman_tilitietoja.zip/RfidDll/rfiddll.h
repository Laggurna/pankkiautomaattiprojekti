#ifndef RFIDDLL_H
#define RFIDDLL_H


#include "rfiddll_global.h"

#include <QSerialPort>
#include <QDebug>
#include <QObject>
#include <QString>

class RfidDll : public QObject
{
    Q_OBJECT

public:

    RFIDDLLSHARED_EXPORT RfidDll();
    void avaaSarjaportti();
    QString RFIDDLLSHARED_EXPORT returnCardSerialNumber();
    QString cardSerialNumber;

private slots:

    void readPort();

private:

    QSerialPort *serial;

signals:

    void dataReadDone();
};

#endif // RFIDDLL_H
