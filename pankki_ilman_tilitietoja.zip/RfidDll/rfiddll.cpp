#include "rfiddll.h"

RfidDll::RfidDll()
{
    serial = new QSerialPort();
    this->avaaSarjaportti();
}

void RfidDll::avaaSarjaportti()
{
    serial->setPortName("com5");
    serial->setBaudRate(QSerialPort::Baud9600);
    serial->setDataBits(QSerialPort::Data8);
    serial->setParity(QSerialPort::NoParity);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setFlowControl(QSerialPort::NoFlowControl);
    serial->setFlowControl(QSerialPort::HardwareControl);
    if (serial->open(QIODevice::ReadWrite))
    {
        qDebug() << serial->portName();
    }
    else
    {
        qDebug() << "Portin avaaminen ei onnistunut!";
    }

    connect(serial,SIGNAL(readyRead()),this,SLOT(readPort()));

}
void RfidDll::readPort()
{
    char data[15];
    int bytesRead;
    bytesRead = serial->read(data, 20);

    data[bytesRead] = '\0';
    if (bytesRead>0)
    {
        cardSerialNumber = data;
        cardSerialNumber.replace("\r\n-",NULL);
        cardSerialNumber.replace("\r\n>",NULL);
        emit dataReadDone();
    }
    else
    {
        qDebug()<<"Virhe korttia luettaessa!";
    }
}

QString RfidDll::returnCardSerialNumber()
{
    return cardSerialNumber;
}
