#include "dialog.h"
#include "ui_dialog.h"


Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    ui->lineEdit_pin->setMaxLength(4);
    setModal(true);
    setWindowFlags(Qt::WindowTitleHint | Qt::WindowMinimizeButtonHint);

}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::clearLineEdit()
{
    ui->lineEdit_pin->clear();
}

void Dialog::on_pushButton_1_clicked()
{
    n = pin.size();
    if (n < 4)
    {
    position++;
    pin.insert(position, QString("1"));
    ui->lineEdit_pin->insert("*");
    qDebug()<<pin;
    }
}

void Dialog::on_pushButton_2_clicked()
{
    n = pin.size();
    if (n < 4)
    {
    position++;
    pin.insert(position, QString("2"));
    ui->lineEdit_pin->insert("*");
    qDebug()<<pin;
    }
}


void Dialog::on_pushButton_3_clicked()
{
    n = pin.size();
    if (n < 4)
    {
    position++;
    pin.insert(position, QString("3"));
    ui->lineEdit_pin->insert("*");
    qDebug()<<pin;
    }
}

void Dialog::on_pushButton_4_clicked()
{
    n = pin.size();
    if (n < 4)
    {
    position++;
    pin.insert(position, QString("4"));
    ui->lineEdit_pin->insert("*");
    qDebug()<<pin;
    }
}

void Dialog::on_pushButton_5_clicked()
{
    n = pin.size();
    if (n < 4)
    {
    position++;
    pin.insert(position, QString("5"));
    ui->lineEdit_pin->insert("*");
    qDebug()<<pin;
    }
}

void Dialog::on_pushButton_6_clicked()
{
    n = pin.size();
    if (n < 4)
    {
    position++;
    pin.insert(position, QString("6"));
    ui->lineEdit_pin->insert("*");
    qDebug()<<pin;
    }
}

void Dialog::on_pushButton_7_clicked()
{
    n = pin.size();
    if (n < 4)
    {
    position++;
    pin.insert(position, QString("7"));
    ui->lineEdit_pin->insert("*");
    qDebug()<<pin;
    }
}

void Dialog::on_pushButton_8_clicked()
{
    n = pin.size();
    if (n < 4)
    {
    position++;
    pin.insert(position, QString("8"));
    ui->lineEdit_pin->insert("*");
    qDebug()<<pin;
    }
}

void Dialog::on_pushButton_9_clicked()
{
    n = pin.size();
    if (n < 4)
    {
    position++;
    pin.insert(position, QString("9"));
    ui->lineEdit_pin->insert("*");
    qDebug()<<pin;
    }
}

void Dialog::on_pushButton_del_clicked()
{

    if (position > -1)
    {
    position --;
    ui->lineEdit_pin->backspace();
    pin.chop(1);
    qDebug()<<pin;
    }

}

void Dialog::on_pushButton_0_clicked()
{
    n = pin.size();
    if (n < 4)
    {
    position++;
    pin.insert(position, QString("0"));
    ui->lineEdit_pin->insert("*");
    qDebug()<<pin;
    }
}

void Dialog::on_pushButton_ok_clicked()
{
    emit pinSignaali();
}

QString Dialog::returnPin()
{
    return pin;
}



