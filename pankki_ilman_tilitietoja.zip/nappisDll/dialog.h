#ifndef DIALOG_H
#define DIALOG_H
#include "dllfilu_global.h"
#include <QDialog>
#include <QString>
#include <QDebug>
#include <QObject>


namespace Ui {
class Dialog;
}

class DLLFILUSHARED_EXPORT Dialog : public QDialog
{
    Q_OBJECT

public:

    explicit Dialog(QWidget *parent = 0);
    QString returnPin();
    ~Dialog();
    QString pin;
    void clearLineEdit();

private:

   int position = -1;
   int n;

signals:

void pinSignaali();

private slots:



    void on_pushButton_1_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_del_clicked();

    void on_pushButton_0_clicked();

    void on_pushButton_ok_clicked();

private:
    Ui::Dialog *ui;
};

#endif // DIALOG_H
