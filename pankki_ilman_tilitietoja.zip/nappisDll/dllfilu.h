#ifndef DLLFILU_H
#define DLLFILU_H


#include "dllfilu_global.h"

class DLLFILUSHARED_EXPORT Dllfilu
{

public:
    Dllfilu();



};

#endif // DLLFILU_H
