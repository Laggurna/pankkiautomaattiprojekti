/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QPushButton *pushButton_1;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QPushButton *pushButton_del;
    QPushButton *pushButton_0;
    QPushButton *pushButton_ok;
    QLineEdit *lineEdit_pin;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QStringLiteral("Dialog"));
        Dialog->resize(180, 249);
        pushButton_1 = new QPushButton(Dialog);
        pushButton_1->setObjectName(QStringLiteral("pushButton_1"));
        pushButton_1->setGeometry(QRect(0, 50, 61, 51));
        QFont font;
        font.setPointSize(24);
        font.setBold(true);
        font.setWeight(75);
        pushButton_1->setFont(font);
        pushButton_2 = new QPushButton(Dialog);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(60, 50, 61, 51));
        pushButton_2->setFont(font);
        pushButton_3 = new QPushButton(Dialog);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(120, 50, 61, 51));
        pushButton_3->setFont(font);
        pushButton_4 = new QPushButton(Dialog);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(0, 100, 61, 51));
        pushButton_4->setFont(font);
        pushButton_5 = new QPushButton(Dialog);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(60, 100, 61, 51));
        pushButton_5->setFont(font);
        pushButton_6 = new QPushButton(Dialog);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(120, 100, 61, 51));
        pushButton_6->setFont(font);
        pushButton_7 = new QPushButton(Dialog);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(0, 150, 61, 51));
        pushButton_7->setFont(font);
        pushButton_8 = new QPushButton(Dialog);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setGeometry(QRect(60, 150, 61, 51));
        pushButton_8->setFont(font);
        pushButton_9 = new QPushButton(Dialog);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(120, 150, 61, 51));
        pushButton_9->setFont(font);
        pushButton_del = new QPushButton(Dialog);
        pushButton_del->setObjectName(QStringLiteral("pushButton_del"));
        pushButton_del->setGeometry(QRect(0, 200, 61, 51));
        pushButton_del->setFont(font);
        pushButton_0 = new QPushButton(Dialog);
        pushButton_0->setObjectName(QStringLiteral("pushButton_0"));
        pushButton_0->setGeometry(QRect(60, 200, 61, 51));
        pushButton_0->setFont(font);
        pushButton_ok = new QPushButton(Dialog);
        pushButton_ok->setObjectName(QStringLiteral("pushButton_ok"));
        pushButton_ok->setGeometry(QRect(120, 200, 61, 51));
        pushButton_ok->setFont(font);
        lineEdit_pin = new QLineEdit(Dialog);
        lineEdit_pin->setObjectName(QStringLiteral("lineEdit_pin"));
        lineEdit_pin->setGeometry(QRect(40, 0, 101, 41));
        QFont font1;
        font1.setPointSize(28);
        font1.setBold(true);
        font1.setWeight(75);
        lineEdit_pin->setFont(font1);

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Dialog", Q_NULLPTR));
        pushButton_1->setText(QApplication::translate("Dialog", "1", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("Dialog", "2", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("Dialog", "3", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("Dialog", "4", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("Dialog", "5", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("Dialog", "6", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("Dialog", "7", Q_NULLPTR));
        pushButton_8->setText(QApplication::translate("Dialog", "8", Q_NULLPTR));
        pushButton_9->setText(QApplication::translate("Dialog", "9", Q_NULLPTR));
        pushButton_del->setText(QApplication::translate("Dialog", "DEL", Q_NULLPTR));
        pushButton_0->setText(QApplication::translate("Dialog", "0", Q_NULLPTR));
        pushButton_ok->setText(QApplication::translate("Dialog", "OK", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
