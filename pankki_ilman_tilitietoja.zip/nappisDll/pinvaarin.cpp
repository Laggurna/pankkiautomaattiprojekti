#include "pinvaarin.h"
#include "ui_pinvaarin.h"

pinvaarin::pinvaarin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::pinvaarin)
{
    ui->setupUi(this);
}

pinvaarin::~pinvaarin()
{
    delete ui;
}
