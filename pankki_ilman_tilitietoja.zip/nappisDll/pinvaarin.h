#ifndef PINVAARIN_H
#define PINVAARIN_H

#include <QDialog>

namespace Ui {
class pinvaarin;
}

class pinvaarin : public QDialog
{
    Q_OBJECT

public:
    explicit pinvaarin(QWidget *parent = 0);
    ~pinvaarin();

private:
    Ui::pinvaarin *ui;
};

#endif // PINVAARIN_H
