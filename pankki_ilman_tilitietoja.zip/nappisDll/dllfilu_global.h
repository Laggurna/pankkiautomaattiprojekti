#ifndef DLLFILU_GLOBAL_H
#define DLLFILU_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(DLLFILU_LIBRARY)
#  define DLLFILUSHARED_EXPORT Q_DECL_EXPORT
#else
#  define DLLFILUSHARED_EXPORT Q_DECL_IMPORT
#endif

#endif // DLLFILU_GLOBAL_H
